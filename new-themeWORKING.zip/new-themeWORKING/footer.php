<footer>
    <div class="footer-content">
        <p>&copy; 2024 Rapid Tech Solutions. All rights reserved.</p>
    </div>
</footer>